/** Automatically generated file. DO NOT MODIFY */
package org.szasar.my2app;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}